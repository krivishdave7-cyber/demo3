# Git and GitHub workshop student pack

This version replaces Activity 2 with the $5 Snack Corner challenge.
Extract the ZIP. Work in your OWN CLONED GitHub repository, not in this extracted pack.

## Before the workshop

- Install Git and VS Code. Create a GitHub account and verify its email.
- Install GitHub Pull Requests and Issues by GitHub in VS Code and sign in when prompted.
- Configure your Git commit name and email with your presenter; account sign-in and commit identity are separate setup steps.
- Create a GitHub repository with README.md, then use F1 > Git: Clone to clone it and open the folder. Keep an existing correct clone if you already have one.

## Choose the folder for the current stage

### 01_DEMO_FOLLOW_ALONG
Use receipt.py from this folder for the opening receipt demonstration. Copy it beside README.md in your clone. The presenter later renames it reciept.py to match the later receipt slides. Keep one receipt file.

### 02_ACTIVITY_1
Activity 1 is unchanged: edit the receipt price from 3.00 to 3.50 on a branch, commit, push and merge a PR. Read this folder's INSTRUCTIONS.md. Copy its reciept.py only if you need the starter; preserve existing work.

### 03_ACTIVITY_2
The NEW activity is an order-planning challenge. Read INSTRUCTIONS.md, then copy ALL CONTENTS of COPY_INTO_YOUR_REPO into the root of your clone. Do not copy the enclosing folder. The four files are order.csv, MENU.md, scripts/check_order.py and .github/workflows/snack-check.yml.

For Activity 2 edit ONLY quantity values in order.csv. Its workflow calculates the real bill and checks the budget, item count and drink requirement. You do not deliberately break any Python code. You may pass on your first attempt.

## Expected Activity 2 layout in your clone

```text
my-trivia-lab/
  README.md
  reciept.py                 (your existing Activity 1 file can stay)
  order.csv                 (edit quantities here)
  MENU.md                   (fixed-price reference)
  scripts/
    check_order.py          (supplied checker)
  .github/
    workflows/
      snack-check.yml       (supplied workflow)
```

Keep your own repository name if different. Merge existing .github and scripts folders rather than replacing them. Dot folders must be copied too.

If you previously used the old Activity 2 receipt syntax workflow, remove or disable ONLY that old receipt-check workflow before doing the new activity. Keep unrelated workflows. The old bracket-breaking exercise and Python matrix challenge are no longer part of this pack.

## The normal VS Code routine

Save with Ctrl+S, inspect Source Control > Changes, click + to stage the intended file, enter a clear message and Commit. Publish Branch for its first upload; use ... > Push on later uploads. Use the bottom-left branch picker to switch branches.

The new Activity 2 takes 17 minutes after the readiness check. Local Python installation is unnecessary because GitHub runs the supplied checker. No partner account is needed.

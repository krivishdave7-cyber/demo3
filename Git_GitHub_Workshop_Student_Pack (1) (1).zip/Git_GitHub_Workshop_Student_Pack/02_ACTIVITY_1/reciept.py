# Calculate a simple receipt.
price = 3.00
quantity = 2
total = price * quantity
print(f"Total: ${total:.2f}")

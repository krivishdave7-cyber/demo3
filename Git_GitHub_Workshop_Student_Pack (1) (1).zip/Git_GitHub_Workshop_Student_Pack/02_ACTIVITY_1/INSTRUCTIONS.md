# Activity 1 - Update your receipt

18 minutes AFTER the readiness check. Work individually in your own cloned repository.

## Readiness check before the timer

1. Open your clone and select main using the bottom-left branch picker.
2. If receipt.py is already at the repository root, rename it reciept.py. If reciept.py already exists, use it. Do not keep both versions.
3. If neither exists, copy ONLY reciept.py from this activity folder beside README.md in your clone. Do not copy the whole 02_ACTIVITY_1 folder.
4. Check these lines in the root reciept.py:

```python
# Calculate a simple receipt.
price = 3.00
quantity = 2
total = price * quantity
print(f"Total: ${total:.2f}")
```

5. If you added, renamed or adjusted this baseline, save, inspect, stage, commit Prepare receipt activity and Push on main. Complete any pending README edit too.
6. Confirm both local and GitHub main show a valid reciept.py at 3.00. Check the GitHub PR extension is signed in. A facilitator can help you remove a finished old update-price branch after verifying its work was merged.

## 0-2 minutes - Create the branch

1. While on main, choose Source Control > ... > Pull.
2. Click main at the bottom-left > Create new branch.... Enter update-price and press Enter.
3. Confirm the branch label now says update-price.

## 2-7 minutes - Edit the receipt

1. Open the ROOT reciept.py in your clone.
2. Change ONLY price = 3.00 to price = 3.50. Keep quantity = 2 and the rest of the file unchanged.
3. Save with Ctrl+S.

## 7-11 minutes - Commit and publish

1. Open Source Control > Changes > reciept.py. Inspect the diff: old 3.00, new 3.50.
2. Click + beside reciept.py. Enter Update receipt price to 3.50 and click Commit.
3. Click Publish Branch and choose origin if asked. If this branch is already linked and published, use ... > Push.
4. On GitHub inspect update-price and confirm its reciept.py contains 3.50.

## 11-16 minutes - Create and merge a pull request

1. Open the GitHub PR view in VS Code and choose Create Pull Request. If needed, press F1 > GitHub Pull Requests: Create Pull Request.
2. Set base to main and source to update-price.
3. Use title Update receipt price to 3.50. Describe the price change and that quantity remains 2.
4. Select Create. Read the changed reciept.py in the PR and check the diff.
5. Open Description, scroll to the merge controls, choose Merge Pull Request and confirm when allowed. You cannot approve your own PR, but you may merge it when repository rules allow.

## 16-18 minutes - Update local main

1. Exit PR review mode if active.
2. Choose main in the bottom-left branch picker.
3. Use Source Control > ... > Pull.
4. Open reciept.py and confirm price = 3.50.

## Show your facilitator

- Your merged PR.
- The price-change commit.
- Local main with reciept.py at 3.50.

With quantity 2, the program's calculated total is 7.00. Running Python locally is optional. Keep this repository for Activity 2.
